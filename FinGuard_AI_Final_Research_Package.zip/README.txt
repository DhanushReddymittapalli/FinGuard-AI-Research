
FINGUARD AI — FINAL RESEARCH PACKAGE

Research theme:
Robust and Explainable Machine Learning for Credit Card Fraud
Detection Under Temporal Distribution Shifts.

Contents:
- Corrected Random Forest, XGBoost and LightGBM model artifacts
- Corrected chronological evaluation metrics
- Corrected SHAP analysis outputs
- Class-wise PSI and PSI bin sensitivity results
- Reconciled advanced research report (DOCX and PDF)
- Reconciled Japan Master's report (DOCX and PDF)

Important methodological notes:
- Chronological timestamp-safe 70/15/15 evaluation.
- Thresholds selected on validation data.
- Later-period data had been examined in preliminary work;
  it is not described as a completely untouched blind holdout.
- Fraud-class PSI findings are exploratory and bin-sensitive
  because the fraud samples are small.
- SHAP attribution does not establish causality.

For full reproduction, retain the original dataset and the
Google Colab notebook containing preprocessing, training,
evaluation and analysis code.

Review dependencies, data provenance, licensing and paths
before sharing or publishing this package.
